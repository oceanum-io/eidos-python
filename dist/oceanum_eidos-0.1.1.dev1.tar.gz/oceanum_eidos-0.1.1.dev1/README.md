# eidos-python

Python bindings for EIDOS

This repo is a submodule of the oceanum library
