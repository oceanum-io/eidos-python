﻿eidoslib
========

.. automodule:: eidoslib

   
   
   

   
   
   

   
   
   

   
   
   .. rubric:: Exceptions

   .. autosummary::
   
      EidosError
   
   



